
import { AIStrategy, AIContext } from '../../core/AIStrategy';
import { Entity } from '../../../types';
import { Steering } from '../../core/Steering';

export class BasicChaserAI implements AIStrategy {
  private desiredVelocity = { x: 0, y: 0 };

  update(entity: Entity, player: Entity, context: AIContext) {
    // 1. Seek Player
    const seek = Steering.seek(entity, player.x, player.y);
    
    // 2. Separate from neighbors (prevent stacking)
    const sep = Steering.separation(entity, context.nearbyEnemies, 30);

    // 3. Organic Jitter (Prevents deadlock when Seek and Separation cancel out)
    // Uses entity ID and time to create deterministic but chaotic noise
    const seed = (entity.id.charCodeAt(0) || 0) + context.time * 0.001;
    const jitterX = Math.sin(seed) * 0.2;
    const jitterY = Math.cos(seed) * 0.2;

    // 4. Combine Forces
    const finalX = seek.x * 1.0 + sep.x * 1.5 + jitterX;
    const finalY = seek.y * 1.0 + sep.y * 1.5 + jitterY;

    // Normalize
    const len = Math.sqrt(finalX*finalX + finalY*finalY);
    if (len > 0) {
        this.desiredVelocity.x = finalX / len;
        this.desiredVelocity.y = finalY / len;
    }

    // Apply with smoothing
    const turnSpeed = 0.15;
    const speed = entity.speed || 0.1;
    
    const vx = (entity.velocity?.x || 0);
    const vy = (entity.velocity?.y || 0);
    
    entity.velocity = {
        x: vx + (this.desiredVelocity.x * speed - vx) * turnSpeed,
        y: vy + (this.desiredVelocity.y * speed - vy) * turnSpeed
    };
  }
}
