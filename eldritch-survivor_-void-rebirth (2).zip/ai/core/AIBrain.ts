
import { Entity } from '../../types';
import { SpatialHash } from '../../SpatialHash';
import { Perception } from './Perception';
import { AIStrategy } from './AIStrategy';
import { AIFactory } from '../AIFactory';

export class AIBrain {
  private entity: Entity;
  private strategy: AIStrategy;
  private thinkTimer: number = 0;
  private readonly baseThinkInterval: number;
  private neighborsBuffer: Entity[] = [];

  constructor(entity: Entity, profileName?: string) {
    this.entity = entity;
    // Map Archetype to Strategy via Factory
    if (entity.archetype) {
        this.strategy = AIFactory.getStrategy(entity.archetype);
    } else {
        // Fallback for minions or unknown
        this.strategy = AIFactory.getStrategy('BASIC_CHASER' as any); 
    }
    
    // Randomize update phase to prevent CPU spikes
    // Base rate: ~20-30 updates/sec (33ms - 50ms)
    this.baseThinkInterval = 33 + Math.random() * 17; 
    this.thinkTimer = Math.random() * this.baseThinkInterval;
  }

  update(delta: number, player: Entity, spatialHash: SpatialHash) {
    this.thinkTimer -= delta;

    // Check if it's time to think
    if (this.thinkTimer <= 0) {
      const distSq = (this.entity.x - player.x) ** 2 + (this.entity.y - player.y) ** 2;
      
      // Dynamic Throttling: Reduce AI frequency based on distance
      // Level 1: Close (< 450px) -> High Freq (1x)
      // Level 2: Medium (< 900px) -> Med Freq (3x)
      // Level 3: Far (> 900px) -> Low Freq (10x)
      let throttleMult = 1;
      
      if (distSq > 900 * 900) {
          throttleMult = 10;
      } else if (distSq > 450 * 450) {
          throttleMult = 3;
      }

      const effectiveInterval = this.baseThinkInterval * throttleMult;

      // Reset timer
      // We add interval to current negative value to maintain cadence, but clamp to avoid 'death spirals' if lagged
      this.thinkTimer += effectiveInterval;
      if (this.thinkTimer < 0) this.thinkTimer = 0; 

      // Optimization: Skip expensive spatial queries for far-away enemies
      // Separation matters less when they are off-screen
      if (throttleMult <= 3) {
          // Only fetch neighbors if reasonably close
          // Note: Perception radius is 100px
          this.neighborsBuffer = Perception.getNearbyEntities(this.entity, spatialHash, 100, 'enemy');
      } else {
          this.neighborsBuffer.length = 0; // Clear buffer
      }

      // Execute Strategy
      // Note: We pass 'effectiveInterval' as delta so AI timers (cooldowns) progress correctly relative to real-time
      this.strategy.update(this.entity, player, {
          delta: effectiveInterval, 
          time: Date.now(),
          spatialHash: spatialHash,
          nearbyEnemies: this.neighborsBuffer
      });
    }
  }
}
