
import { Entity, WeaponType, EnemyArchetype, BossType, FloatingText, MinionType, ChestType } from '../types';
import { drawPolygon } from '../art/primitives/Shapes';
import { PowerRegistry } from '../powers/index'; 
import { EnemyArtRegistry } from '../art/enemies/EnemyArtRegistry';
import { BossRegistry } from '../bosses/index';
import { GAME_OPTIONS } from '../gameOptions';
import { PlayerArt } from '../art/player';
import { AccessoryRegistry } from '../accessories/index';
import { DrawUtils } from '../art/primitives/DrawUtils';
import { TextureManager } from './TextureManager';
import { MinionArtRegistry } from '../art/minions/MinionArtRegistry'; 
import { CharacterId } from '../types/CharacterTypes';

export class ProceduralRenderer {
  
  static drawBackground(ctx: CanvasRenderingContext2D, width: number, height: number, camX: number, camY: number) {
    // ... (Keep existing implementation) ...
    ctx.fillStyle = GAME_OPTIONS.COLORS.BACKGROUND;
    ctx.fillRect(0, 0, width, height);

    const gridSize = GAME_OPTIONS.GRID_SIZE;
    
    ctx.strokeStyle = '#151520';
    ctx.lineWidth = 2;
    
    const startX = Math.floor(camX / gridSize) * gridSize;
    const startY = Math.floor(camY / gridSize) * gridSize;
    const endX = camX + width + gridSize;
    const endY = camY + height + gridSize;

    for (let x = startX; x < endX; x += gridSize) {
        for (let y = startY; y < endY; y += gridSize) {
            const screenX = x - camX;
            const screenY = y - camY;
            
            ctx.strokeRect(screenX, screenY, gridSize, gridSize);

            const seed = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
            const rand = seed - Math.floor(seed);

            if (rand > 0.8) {
                ctx.fillStyle = '#1a1a25';
                ctx.fillRect(screenX + 10, screenY + 10, 20, 20); 
            } else if (rand < 0.1) {
                ctx.fillStyle = '#181822';
                ctx.font = '20px serif';
                ctx.fillText('†', screenX + gridSize/2, screenY + gridSize/2);
            }
        }
    }
  }

  static drawLighting(ctx: CanvasRenderingContext2D, width: number, height: number, player: Entity, projectiles: Entity[], camX: number, camY: number) {
      // ... (Keep existing implementation) ...
      ctx.globalCompositeOperation = 'multiply';
      const grad = ctx.createRadialGradient(width/2, height/2, height * 0.4, width/2, height/2, height);
      grad.addColorStop(0, 'rgba(0,0,0,0)');
      grad.addColorStop(1, 'rgba(0,0,0,0.85)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      ctx.globalCompositeOperation = 'screen'; 
      const pScreenX = player.x - camX;
      const pScreenY = player.y - camY;
      const lightGrad = ctx.createRadialGradient(pScreenX, pScreenY, 20, pScreenX, pScreenY, 300);
      lightGrad.addColorStop(0, 'rgba(100, 200, 255, 0.3)');
      lightGrad.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = lightGrad;
      ctx.fillRect(0, 0, width, height);

      for (const p of projectiles) {
          if (!p.active) continue;
          const px = p.x - camX;
          const py = p.y - camY;
          if (px < 0 || px > width || py < 0 || py > height) continue;
          ctx.fillStyle = 'rgba(100, 255, 255, 0.1)';
          ctx.beginPath();
          ctx.arc(px, py, p.size * 3, 0, Math.PI * 2);
          ctx.fill();
      }
      ctx.globalCompositeOperation = 'source-over';
  }

  static drawPlayer(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, camX: number, camY: number, charId?: CharacterId) {
    const time = Date.now() * 0.001;
    const px = x - camX;
    const py = y - camY;
    PlayerArt.draw(ctx, px, py, size, time, charId); // Pass character ID
  }

  static drawEnemy(ctx: CanvasRenderingContext2D, e: Entity, camX: number, camY: number) {
    if (!e.active || e.state === 'invisible') return;
    const px = e.x - camX;
    const py = e.y - camY;
    const margin = e.size * 3;
    if (px < -margin || px > ctx.canvas.width + margin || py < -margin || py > ctx.canvas.height + margin) return;
    const time = Date.now() * 0.001;
    if ((e.type === 'boss' && e.bossType) || e.isKing) {
        DrawUtils.drawShadow(ctx, e.size * 0.8);
        ctx.save();
        ctx.translate(px, py);
        if (e.isKing) ctx.scale(1.2, 1.2);
        if (e.type === 'boss' && e.bossType) {
            const bossMod = BossRegistry[e.bossType];
            if (bossMod && bossMod.art) {
                bossMod.art.draw(ctx, 0, 0, e.size, time, 0, e.state);
            }
        } else if (e.artKey) {
            EnemyArtRegistry[e.artKey as EnemyArchetype].draw(ctx, 0, 0, e.size, time, 0, { isKing: e.isKing });
        }
        ctx.restore();
        return;
    }
    if (e.artKey) {
        const cachedCanvas = TextureManager.getEnemyTexture(e.artKey as EnemyArchetype, e.size);
        const halfSize = cachedCanvas.width / 2;
        DrawUtils.drawShadow(ctx, e.size * 0.8);
        ctx.save();
        ctx.translate(px, py);
        const breathe = 1 + Math.sin(time * 5 + e.id.charCodeAt(0)) * 0.05;
        const wobble = Math.cos(time * 3 + e.id.charCodeAt(0)) * 0.1;
        ctx.scale(breathe, breathe);
        ctx.rotate(wobble);
        ctx.drawImage(cachedCanvas, -halfSize, -halfSize);
        if (e.lastHitTime && Date.now() - e.lastHitTime < 100) {
            ctx.globalCompositeOperation = 'screen';
            ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
            ctx.beginPath();
            ctx.arc(0, 0, e.size, 0, Math.PI*2);
            ctx.fill();
            ctx.globalCompositeOperation = 'source-over';
        }
        ctx.restore();
    } 
    else {
      ctx.fillStyle = '#ff00ff';
      ctx.beginPath();
      ctx.arc(px, py, e.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  static drawProjectile(ctx: CanvasRenderingContext2D, p: any, camX: number, camY: number) {
    const px = p.x - camX;
    const py = p.y - camY;
    if (px < -150 || px > ctx.canvas.width + 150 || py < -150 || py > ctx.canvas.height + 150) return;
    const time = Date.now() * 0.001;
    const mod = PowerRegistry[p.type as WeaponType];
    let angle = 0;
    if (p.vx !== 0 || p.vy !== 0) {
      angle = Math.atan2(p.vy, p.vx);
    }
    if (mod && mod.art) {
      mod.art.drawProjectile(ctx, px, py, p.size, time, p.level || 1, angle, p.life, p.maxLife, p, camX, camY);
    } else {
      ctx.shadowColor = '#fff';
      ctx.shadowBlur = 10;
      ctx.fillStyle = '#fff';
      ctx.beginPath(); 
      ctx.arc(px, py, p.size, 0, Math.PI * 2); 
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  }

  static drawGem(ctx: CanvasRenderingContext2D, g: any, camX: number, camY: number) {
    const px = g.x - camX;
    const py = g.y - camY;
    if (px < -20 || px > ctx.canvas.width + 20 || py < -20 || py > ctx.canvas.height + 20) return;
    const time = Date.now() * 0.001;
    const bob = Math.sin(time * 6 + g.x) * 3;
    const isSuper = !!g.isSuper;
    const drawY = py + bob;
    ctx.save();
    ctx.translate(px, drawY);
    DrawUtils.drawGlow(ctx, g.size * 2, isSuper ? '#ffaa00' : '#00bfff', 0.6);
    ctx.restore();
    const color = isSuper ? GAME_OPTIONS.COLORS.GEM_SUPER : GAME_OPTIONS.COLORS.GEM;
    ctx.fillStyle = color;
    ctx.save();
    ctx.translate(px, drawY);
    ctx.rotate(time);
    if (isSuper) {
       drawPolygon(ctx, [
        {x: 0, y: -g.size}, {x: g.size, y: -g.size/2}, {x: g.size, y: g.size/2},
        {x: 0, y: g.size}, {x: -g.size, y: g.size/2}, {x: -g.size, y: -g.size/2}
      ]);
    } else {
       ctx.beginPath();
       ctx.moveTo(0, -g.size); 
       ctx.lineTo(g.size, 0); 
       ctx.lineTo(0, g.size); 
       ctx.lineTo(-g.size, 0); 
       ctx.closePath();
       ctx.fill();
    }
    ctx.fillStyle = 'rgba(255,255,255,0.8)';
    ctx.beginPath();
    ctx.arc(-2, -2, 1, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();
  }

  static drawChest(ctx: CanvasRenderingContext2D, e: Entity, camX: number, camY: number) {
      const px = e.x - camX;
      const py = e.y - camY;
      if (px < -100 || px > ctx.canvas.width + 100 || py < -100 || py > ctx.canvas.height + 100) return;
      const time = Date.now() * 0.001;
      
      const bounce = Math.sin(time * 2.5) * 5;
      const glowIntensity = (Math.sin(time * 4) + 1) * 0.5;
      const isPowerChest = e.chestType === ChestType.POWER;

      // COLORS
      const beamColor = isPowerChest ? 'rgba(0, 255, 255, 0.4)' : 'rgba(255, 215, 0, 0.4)';
      const particleColor = isPowerChest ? '#00ffff' : '#ffd700';
      const woodDark = isPowerChest ? '#1a1a2e' : '#3e2723';
      const woodMid = isPowerChest ? '#303050' : '#5d4037';
      const metalBase = isPowerChest ? '#004444' : '#b8860b';
      const metalLight = isPowerChest ? '#00ffff' : '#ffd700';
      const gemColor = isPowerChest ? '#8a2be2' : '#00ffff';

      ctx.save();
      ctx.translate(px, py + bounce);

      // --- 1. BEAM OF LIGHT (God Ray) ---
      ctx.globalCompositeOperation = 'screen';
      const beamW = 60;
      const beamH = 300;
      const beamGrad = ctx.createLinearGradient(0, 0, 0, -beamH);
      beamGrad.addColorStop(0, beamColor);
      beamGrad.addColorStop(1, 'rgba(0,0,0,0)');
      
      ctx.fillStyle = beamGrad;
      ctx.beginPath();
      ctx.moveTo(-beamW/2, 0);
      ctx.lineTo(beamW/2, 0);
      ctx.lineTo(beamW, -beamH);
      ctx.lineTo(-beamW, -beamH);
      ctx.fill();
      ctx.globalCompositeOperation = 'source-over';

      // --- 2. SHADOW ---
      DrawUtils.drawShadow(ctx, 15 + bounce * 0.2);

      // --- 3. PARTICLES ---
      ctx.fillStyle = particleColor;
      for(let i=0; i<3; i++) {
          const t = time + i;
          const pX = Math.sin(t * 3) * 20;
          const pY = -10 - (t * 50 % 60);
          const pSize = 2 + Math.sin(t * 10);
          ctx.globalAlpha = 1 - (Math.abs(pY)/60);
          ctx.beginPath();
          ctx.arc(pX, pY, pSize, 0, Math.PI*2);
          ctx.fill();
      }
      ctx.globalAlpha = 1;

      // --- 4. CHEST BODY (Trapezoid Base) ---
      const w = 36;
      const h = 24;
      
      // Wood/Stone Gradient
      const woodGrad = ctx.createLinearGradient(-w/2, -h, w/2, 0);
      woodGrad.addColorStop(0, woodDark); 
      woodGrad.addColorStop(0.5, woodMid); 
      woodGrad.addColorStop(1, woodDark);

      ctx.fillStyle = woodGrad;
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 1;

      ctx.beginPath();
      ctx.moveTo(-w/2 + 2, -h); // Top Left
      ctx.lineTo(w/2 - 2, -h);  // Top Right
      ctx.lineTo(w/2, 0);       // Bottom Right
      ctx.lineTo(-w/2, 0);      // Bottom Left
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // --- 5. METAL STRAPS ---
      const metalGrad = DrawUtils.createMetallicGradient(ctx, w, metalBase, metalLight);
      ctx.fillStyle = metalGrad;
      
      const strapW = 6;
      // Left Strap
      ctx.fillRect(-w/2 + 6, -h, strapW, h);
      // Right Strap
      ctx.fillRect(w/2 - 6 - strapW, -h, strapW, h);

      // --- 6. LID (Arched Top) ---
      const lidH = 14;
      ctx.fillStyle = woodGrad;
      ctx.beginPath();
      ctx.moveTo(-w/2, -h);
      ctx.bezierCurveTo(-w/2, -h - lidH, w/2, -h - lidH, w/2, -h); // Arch
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Lid Straps
      ctx.fillStyle = metalGrad;
      // Left
      ctx.beginPath(); 
      ctx.moveTo(-w/2 + 6, -h);
      ctx.bezierCurveTo(-w/2 + 6, -h - lidH, -w/2 + 6 + strapW, -h - lidH, -w/2 + 6 + strapW, -h);
      ctx.fill();
      // Right
      ctx.beginPath(); 
      ctx.moveTo(w/2 - 6 - strapW, -h);
      ctx.bezierCurveTo(w/2 - 6 - strapW, -h - lidH, w/2 - 6, -h - lidH, w/2 - 6, -h);
      ctx.fill();

      // --- 7. LOCK & GLOW ---
      // Glowing Gap
      ctx.strokeStyle = isPowerChest ? `rgba(0, 255, 255, ${0.5 + glowIntensity * 0.5})` : `rgba(255, 215, 0, ${0.5 + glowIntensity * 0.5})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-w/2 + 2, -h);
      ctx.lineTo(w/2 - 2, -h);
      ctx.stroke();

      // Lock Plate
      ctx.fillStyle = '#111';
      ctx.fillRect(-5, -h - 4, 10, 8);
      
      // Rune/Gem
      DrawUtils.drawGlow(ctx, 4, gemColor, 0.8);
      ctx.fillStyle = gemColor;
      ctx.beginPath();
      ctx.arc(0, -h, 3, 0, Math.PI*2);
      ctx.fill();

      ctx.restore();
  }

  static drawAccessoryDrop(ctx: CanvasRenderingContext2D, e: Entity, camX: number, camY: number) {
      const px = e.x - camX;
      const py = e.y - camY;
      if (px < -50 || px > ctx.canvas.width + 50 || py < -50 || py > ctx.canvas.height + 50) return;
      const time = Date.now() * 0.001;
      if (e.accessoryType && AccessoryRegistry[e.accessoryType]) {
          const mod = AccessoryRegistry[e.accessoryType];
          mod.art.drawWorld(ctx, px, py, 24, time);
      }
  }

  static drawMinion(ctx: CanvasRenderingContext2D, m: Entity, camX: number, camY: number) {
      const px = m.x - camX;
      const py = m.y - camY;
      if (px < -100 || px > ctx.canvas.width + 100 || py < -100 || py > ctx.canvas.height + 100) return;
      const time = Date.now() * 0.001;
      DrawUtils.drawShadow(ctx, m.size * 0.8);
      if (m.minionType && MinionArtRegistry[m.minionType]) {
          const art = MinionArtRegistry[m.minionType];
          art.draw(ctx, px, py, m.size, time, 0, m);
      } else {
          ctx.fillStyle = '#00ffff';
          ctx.beginPath();
          ctx.arc(px, py, m.size, 0, Math.PI*2);
          ctx.fill();
      }
  }

  static drawFloatingText(ctx: CanvasRenderingContext2D, t: FloatingText, camX: number, camY: number) {
    if (!t.active) return;
    const px = t.x - camX;
    const py = t.y - camY;
    if (px < -50 || px > ctx.canvas.width + 50 || py < -50 || py > ctx.canvas.height + 50) return;
    const lifeRatio = t.life / t.maxLife;
    ctx.globalAlpha = lifeRatio;
    ctx.font = 'bold 16px "Press Start 2P", sans-serif'; 
    ctx.textAlign = 'center';
    ctx.fillStyle = '#000';
    ctx.fillText(t.text, px + 2, py + 2);
    ctx.fillStyle = t.color;
    ctx.fillText(t.text, px, py);
    ctx.globalAlpha = 1.0; 
  }
}
