
export const ANGEL_STATS = {
  HP: 120, // Buffed from 50
  SPEED: 0.17,
  HEAL_RANGE: 400,
  HEAL_AMOUNT: 20,
  WARD_COOLDOWN: 5000
};
