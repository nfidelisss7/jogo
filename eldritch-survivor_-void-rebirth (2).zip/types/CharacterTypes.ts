
export enum CharacterId {
  VOID_WALKER = 'VOID_WALKER',
  BLOOD_WEAVER = 'BLOOD_WEAVER',
  IRON_WARDEN = 'IRON_WARDEN'
}

export interface CharacterStatsModifier {
  maxHpMult: number;      // Multiplicador de Vida (1.0 = base)
  moveSpeedMult: number;  // Multiplicador de Velocidade
  damageMult: number;     // Multiplicador de Dano Global
  cooldownMult: number;   // Multiplicador de Cooldown (0.9 = 10% mais rápido)
  armor: number;          // Redução de dano flat ou percentual
  pickupRangeMult: number;
}

export interface CharacterTheme {
  primaryColor: string;
  secondaryColor: string;
  glowColor: string;
  robeStyle: 'tattered' | 'elegant' | 'armored';
}

export interface CharacterDefinition {
  id: CharacterId;
  name: string;
  title: string;
  description: string;
  stats: CharacterStatsModifier;
  theme: CharacterTheme;
}
