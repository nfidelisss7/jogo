
import { DrawUtils } from '../primitives/DrawUtils';
import { CharacterId } from '../../types/CharacterTypes';
import { CharacterRegistry } from '../../characters/index';

export const PlayerArt = {
  draw(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, time: number, charId: CharacterId = CharacterId.VOID_WALKER) {
    ctx.save();
    ctx.translate(x, y);

    const theme = CharacterRegistry[charId]?.theme || CharacterRegistry[CharacterId.VOID_WALKER].theme;

    // --- ANIMATION STATE ---
    const hover = Math.sin(time * 2) * 3;
    const breathe = 1 + Math.sin(time * 3) * 0.02; 
    
    ctx.translate(0, hover);
    ctx.scale(breathe, 1 / breathe);

    // --- 1. SHADOW ---
    ctx.save();
    ctx.translate(0, -hover + size * 2.2);
    ctx.scale(1.0 - (hover / 30), 0.3);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.beginPath();
    ctx.arc(0, 0, size * 0.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // --- COLOR PALETTE ---
    const colorRobeDark = theme.primaryColor;
    const colorRobeMid  = theme.secondaryColor;
    const colorTrim     = theme.robeStyle === 'armored' ? '#888' : '#303050';
    const colorArcane   = theme.glowColor;

    // --- 2. BACK ROBE ---
    const wind = Math.sin(time * 2.5) * 4;
    ctx.save();
    ctx.fillStyle = colorRobeDark;
    ctx.beginPath();
    ctx.moveTo(-size * 0.6, 0); 
    ctx.quadraticCurveTo(-size * 0.8 + wind, size * 1.5, -size * 0.9 + wind, size * 2.2);
    ctx.lineTo(size * 0.9 + wind, size * 2.2);
    ctx.quadraticCurveTo(size * 0.8 + wind, size * 1.5, size * 0.6, 0);
    ctx.fill();
    ctx.restore();

    // --- 3. MAIN BODY ---
    const bodyGrad = ctx.createLinearGradient(-size, -size, size, size * 2);
    bodyGrad.addColorStop(0, colorRobeMid);
    bodyGrad.addColorStop(1, '#000');
    
    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    
    if (theme.robeStyle === 'armored') {
        // Broad shoulders
        ctx.moveTo(-size * 0.5, -size * 0.8);
        ctx.lineTo(size * 0.5, -size * 0.8);
        ctx.lineTo(size * 0.7, -size * 0.5); // Pauldron R
        ctx.lineTo(size * 0.5, size * 0.8);
        ctx.lineTo(size * 0.6, size * 1.8);
        ctx.lineTo(-size * 0.6, size * 1.8);
        ctx.lineTo(-size * 0.5, size * 0.8);
        ctx.lineTo(-size * 0.7, -size * 0.5); // Pauldron L
    } else {
        // Slim Robe
        ctx.moveTo(-size * 0.4, -size * 0.8);
        ctx.lineTo(size * 0.4, -size * 0.8);
        ctx.lineTo(size * 0.6, -size * 0.4); 
        ctx.lineTo(size * 0.4, size * 0.8);
        ctx.lineTo(size * 0.5, size * 1.8);
        ctx.lineTo(-size * 0.5, size * 1.8);
        ctx.lineTo(-size * 0.4, size * 0.8);
        ctx.lineTo(-size * 0.6, -size * 0.4);
    }
    
    ctx.closePath();
    ctx.fill();

    // Sash / Belt
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(-size*0.4, size*0.6, size*0.8, size*0.2);
    
    // Trim
    ctx.strokeStyle = colorTrim;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, -size * 0.8);
    ctx.lineTo(0, size * 1.8);
    ctx.stroke();

    // --- 4. MANTLE / COWL ---
    ctx.fillStyle = colorRobeMid;
    ctx.beginPath();
    if (theme.robeStyle === 'armored') {
        // Chestplate look
        ctx.moveTo(-size*0.7, -size*0.5);
        ctx.lineTo(size*0.7, -size*0.5);
        ctx.lineTo(0, size*0.5);
    } else {
        ctx.moveTo(-size * 0.6, -size * 0.4);
        ctx.quadraticCurveTo(0, -size * 1.0, size * 0.6, -size * 0.4); 
        ctx.lineTo(size * 0.5, 0); 
        ctx.lineTo(0, size * 0.4); 
        ctx.lineTo(-size * 0.5, 0);
    }
    ctx.closePath();
    ctx.fill();
    
    ctx.strokeStyle = colorTrim;
    ctx.lineWidth = 1;
    ctx.stroke();

    // --- 5. HANDS ---
    const handBob = Math.sin(time * 4) * 2;
    const drawHand = (hx: number, hy: number) => {
        ctx.save();
        ctx.translate(hx, hy + handBob);
        ctx.fillStyle = colorRobeDark;
        ctx.beginPath();
        ctx.arc(0, 0, 4, 0, Math.PI*2);
        ctx.fill();
        DrawUtils.drawGlow(ctx, 8, colorArcane, 0.4);
        ctx.fillStyle = '#fff';
        ctx.globalAlpha = 0.8;
        ctx.beginPath();
        ctx.arc(0, 0, 2, 0, Math.PI*2);
        ctx.fill();
        ctx.restore();
    };
    drawHand(-size * 0.7, 0);
    drawHand(size * 0.7, 0);

    // --- 6. HEAD ---
    ctx.save();
    ctx.translate(0, -size * 0.9);

    ctx.fillStyle = colorRobeDark;
    ctx.beginPath();
    
    if (theme.robeStyle === 'armored') {
        // Helmet
        ctx.rect(-size*0.4, -size*0.5, size*0.8, size*0.9);
    } else {
        // Hood
        ctx.arc(0, -2, size * 0.45, Math.PI, 0); 
        ctx.lineTo(size * 0.45, size * 0.3);     
        ctx.lineTo(0, size * 0.5);               
        ctx.lineTo(-size * 0.45, size * 0.3);
    }
    ctx.closePath();
    ctx.fill();

    // Face/Void
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.ellipse(0, 0, size * 0.35, size * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Eyes
    ctx.shadowBlur = 10;
    ctx.shadowColor = colorArcane;
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(-4, 2, 2, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(4, 2, 2, 0, Math.PI * 2); ctx.fill();
    
    ctx.shadowBlur = 0;
    ctx.restore();

    // --- 7. HALO/AURA ---
    ctx.save();
    ctx.translate(0, -size * 1.0); 
    ctx.rotate(time * 0.5); 
    ctx.scale(1, 0.3); 
    
    ctx.strokeStyle = theme.glowColor;
    ctx.globalAlpha = 0.3;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(0, 0, size * 1.2, 0, Math.PI * 2);
    ctx.stroke();
    
    // Orbs
    const runes = 3;
    for(let i=0; i<runes; i++) {
        const ang = (i / runes) * Math.PI * 2;
        const rx = Math.cos(ang) * size * 1.2;
        const ry = Math.sin(ang) * size * 1.2;
        ctx.fillStyle = theme.glowColor;
        ctx.globalAlpha = 1;
        ctx.beginPath();
        ctx.arc(rx, ry, 2, 0, Math.PI*2);
        ctx.fill();
    }
    
    ctx.restore();
    ctx.restore();
  }
};
