
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    // Presa (Gradiente de Osso)
    const boneGrad = ctx.createLinearGradient(0, -size * 0.5, 0, size * 0.5);
    boneGrad.addColorStop(0, '#fff'); // Raiz
    boneGrad.addColorStop(1, '#e0e0c0'); // Ponta amarelada

    ctx.fillStyle = boneGrad;
    ctx.strokeStyle = '#ccc';
    ctx.lineWidth = 1;

    ctx.beginPath();
    ctx.moveTo(-size * 0.3, -size * 0.4); // Raiz Esq
    ctx.quadraticCurveTo(0, -size * 0.2, size * 0.3, -size * 0.4); // Raiz Dir
    ctx.quadraticCurveTo(size * 0.4, 0, 0, size * 0.6); // Ponta
    ctx.quadraticCurveTo(-size * 0.4, 0, -size * 0.3, -size * 0.4); // Volta
    ctx.fill();
    ctx.stroke();

    // Gota de Sangue
    const bloodGrad = ctx.createRadialGradient(0, size * 0.6, 0, 0, size * 0.6, size * 0.2);
    bloodGrad.addColorStop(0, '#ff6666');
    bloodGrad.addColorStop(1, '#aa0000');

    ctx.fillStyle = bloodGrad;
    ctx.beginPath();
    ctx.arc(0, size * 0.6, size * 0.15, 0, Math.PI * 2);
    ctx.fill();

    // Brilho na Gota
    ctx.fillStyle = '#fff';
    ctx.globalAlpha = 0.7;
    ctx.beginPath();
    ctx.arc(-size * 0.05, size * 0.55, size * 0.04, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  },
  drawWorld: (ctx, x, y, size, time) => {
    const hover = Math.sin(time * 3) * 3;
    
    ctx.save();
    ctx.translate(x, y + hover);
    art.drawIcon(ctx, 0, 0, size);
    
    // Gota pingando (Animação)
    const dripY = (time * 50) % (size * 1.5);
    if (dripY > size * 0.6) {
        ctx.globalAlpha = 1 - (dripY / (size * 1.5)); // Fade out
        ctx.fillStyle = '#a00';
        ctx.beginPath();
        ctx.arc(0, dripY, size * 0.1, 0, Math.PI * 2);
        ctx.fill();
    }
    
    ctx.restore();
  }
};
