
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    const ringThickness = size * 0.15;

    // Aro Dourado
    ctx.strokeStyle = '#ffd700';
    ctx.lineWidth = ringThickness;
    ctx.shadowColor = '#b8860b';
    ctx.shadowBlur = 5;
    
    ctx.beginPath();
    ctx.arc(0, 0, size * 0.5, 0, Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Joia (Rubi)
    const gemGrad = ctx.createRadialGradient(0, -size * 0.5, 0, 0, -size * 0.5, size * 0.3);
    gemGrad.addColorStop(0, '#ff4444');
    gemGrad.addColorStop(1, '#8a0b0b');

    ctx.fillStyle = gemGrad;
    ctx.lineWidth = 1;
    ctx.strokeStyle = '#500';
    
    ctx.beginPath();
    ctx.arc(0, -size * 0.5, size * 0.25, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Brilho na Joia
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.beginPath();
    ctx.ellipse(-size * 0.08, -size * 0.55, size * 0.08, size * 0.04, Math.PI / 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  },
  drawWorld: (ctx, x, y, size, time) => {
    const hover = Math.sin(time * 2) * 3;
    // Pulso de vida (Simula batimento cardíaco)
    const beat = 1 + (Math.sin(time * 10) > 0.8 ? 0.1 : 0); 

    ctx.save();
    ctx.translate(x, y + hover);
    ctx.scale(beat, beat);
    art.drawIcon(ctx, 0, 0, size);
    ctx.restore();
  }
};
