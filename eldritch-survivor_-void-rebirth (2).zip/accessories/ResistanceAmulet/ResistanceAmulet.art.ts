
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    const strokeWidth = Math.max(1.5, size * 0.08);

    // Corpo do Escudo (Gradiente Metálico)
    const grad = ctx.createLinearGradient(-size * 0.5, -size * 0.5, size * 0.5, size * 0.5);
    grad.addColorStop(0, '#555');
    grad.addColorStop(0.5, '#aaa');
    grad.addColorStop(1, '#333');

    ctx.fillStyle = grad;
    ctx.strokeStyle = '#eee';
    ctx.lineWidth = strokeWidth;

    ctx.beginPath();
    ctx.moveTo(0, size * 0.6);
    ctx.bezierCurveTo(size, -size * 0.3, size, -size * 0.8, 0, -size * 0.5); // Topo direito
    ctx.bezierCurveTo(-size, -size * 0.8, -size, -size * 0.3, 0, size * 0.6); // Topo esquerdo
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Núcleo de Energia (Proteção)
    ctx.beginPath();
    ctx.fillStyle = '#4caf50'; // Verde resistente
    ctx.arc(0, -size * 0.1, size * 0.15, 0, Math.PI * 2);
    ctx.fill();

    // Brilho especular
    ctx.globalAlpha = 0.6;
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(-size * 0.1, -size * 0.2, size * 0.05, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  },
  drawWorld: (ctx, x, y, size, time) => {
    const hover = Math.sin(time * 2) * 4;
    const scale = 1 + Math.sin(time * 3) * 0.05;
    
    ctx.save();
    ctx.translate(x, y + hover);
    ctx.scale(scale, scale);
    art.drawIcon(ctx, 0, 0, size);
    
    // Aura de defesa
    ctx.globalAlpha = 0.2 + Math.sin(time * 4) * 0.1;
    ctx.strokeStyle = '#fff';
    ctx.beginPath();
    ctx.arc(0, 0, size * 0.8, 0, Math.PI * 2);
    ctx.stroke();
    
    ctx.restore();
  }
};
