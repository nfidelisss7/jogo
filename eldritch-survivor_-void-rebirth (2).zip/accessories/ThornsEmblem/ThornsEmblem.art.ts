
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    const spikeCount = 8;
    const innerRadius = size * 0.3;
    const outerRadius = size * 0.7;

    // Estrela de Espinhos
    const grad = ctx.createRadialGradient(0, 0, innerRadius, 0, 0, outerRadius);
    grad.addColorStop(0, '#555');
    grad.addColorStop(1, '#222');

    ctx.fillStyle = grad;
    ctx.strokeStyle = '#a00'; // Contorno vermelho agressivo
    ctx.lineWidth = size * 0.05;
    ctx.lineJoin = 'miter';

    ctx.beginPath();
    for (let i = 0; i < spikeCount * 2; i++) {
        const angle = (i / (spikeCount * 2)) * Math.PI * 2;
        const r = i % 2 === 0 ? outerRadius : innerRadius;
        const px = Math.cos(angle) * r;
        const py = Math.sin(angle) * r;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Núcleo de Sangue
    ctx.fillStyle = '#8a0b0b';
    ctx.beginPath();
    ctx.arc(0, 0, innerRadius * 0.6, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  },
  drawWorld: (ctx, x, y, size, time) => {
    const hover = Math.sin(time * 3) * 3;
    const rotate = Math.sin(time) * 0.1; // Rotação leve e ameaçadora

    ctx.save();
    ctx.translate(x, y + hover);
    ctx.rotate(rotate);
    art.drawIcon(ctx, 0, 0, size);
    
    // Brilho pulsante vermelho
    if (Math.sin(time * 5) > 0) {
        ctx.globalAlpha = 0.3;
        ctx.fillStyle = '#f00';
        ctx.beginPath();
        ctx.arc(0, 0, size * 0.8, 0, Math.PI * 2);
        ctx.fill();
    }
    
    ctx.restore();
  }
};
