
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    // Asa Aerodinâmica (Gradiente Elétrico)
    const grad = ctx.createLinearGradient(-size * 0.5, 0, size * 0.5, 0);
    grad.addColorStop(0, '#00bcd4');
    grad.addColorStop(1, '#e0f7fa');

    ctx.fillStyle = grad;
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = size * 0.05;
    ctx.lineJoin = 'round';

    ctx.beginPath();
    // Forma de asa estilizada
    ctx.moveTo(-size * 0.4, size * 0.2);
    ctx.quadraticCurveTo(-size * 0.6, -size * 0.6, size * 0.5, -size * 0.8); // Ponta superior
    ctx.quadraticCurveTo(0, -size * 0.2, size * 0.2, 0); 
    ctx.quadraticCurveTo(0, size * 0.4, -size * 0.4, size * 0.2);
    ctx.fill();
    ctx.stroke();

    // Detalhes de velocidade (Linhas de vento)
    ctx.beginPath();
    ctx.moveTo(-size * 0.6, size * 0.3);
    ctx.lineTo(-size * 0.2, size * 0.1);
    ctx.stroke();

    ctx.restore();
  },
  drawWorld: (ctx, x, y, size, time) => {
    const hover = Math.sin(time * 5) * 5; // Rápido
    
    ctx.save();
    ctx.translate(x, y + hover);
    // Inclinação para frente (velocidade)
    ctx.rotate(0.2); 
    
    art.drawIcon(ctx, 0, 0, size);

    // Partículas elétricas (Sparks)
    if (Math.random() > 0.5) {
        ctx.fillStyle = '#ffeb3b';
        const sparkX = (Math.random() - 0.5) * size;
        const sparkY = (Math.random() - 0.5) * size;
        ctx.fillRect(sparkX, sparkY, 2, 2);
    }

    ctx.restore();
  }
};
