
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    // Corrente/Borda Prateada
    ctx.strokeStyle = '#c0c0c0';
    ctx.lineWidth = size * 0.1;
    ctx.beginPath();
    ctx.arc(0, 0, size * 0.5, 0, Math.PI * 2);
    ctx.stroke();

    // Vazio (Gradiente Profundo)
    const voidGrad = ctx.createRadialGradient(0, 0, size * 0.1, 0, 0, size * 0.5);
    voidGrad.addColorStop(0, '#000'); // Centro negro
    voidGrad.addColorStop(0.5, '#4b0082'); // Índigo
    voidGrad.addColorStop(1, '#8a2be2'); // Violeta

    ctx.fillStyle = voidGrad;
    ctx.beginPath();
    ctx.arc(0, 0, size * 0.45, 0, Math.PI * 2);
    ctx.fill();

    // Espiral Etérea
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    // Desenha uma espiral simples
    for(let i=0; i<30; i++) {
        const angle = i * 0.5;
        const radius = i * (size * 0.015);
        const sx = Math.cos(angle) * radius;
        const sy = Math.sin(angle) * radius;
        if(i===0) ctx.moveTo(sx, sy);
        else ctx.lineTo(sx, sy);
    }
    ctx.stroke();

    ctx.restore();
  },
  drawWorld: (ctx, x, y, size, time) => {
    const hover = Math.sin(time * 2) * 4;
    
    ctx.save();
    ctx.translate(x, y + hover);
    
    // Rotação do ícone interno
    ctx.save();
    ctx.rotate(time); // Gira o amuleto
    art.drawIcon(ctx, 0, 0, size);
    ctx.restore();

    // Partículas sugadas (Vortex)
    ctx.fillStyle = '#8a2be2';
    for(let i=0; i<3; i++) {
        const t = time + i * 2;
        const r = size * 0.8 * ((Math.sin(t)+1)/2);
        const a = t * 3;
        ctx.globalAlpha = 1 - (r / size);
        ctx.fillRect(Math.cos(a)*r, Math.sin(a)*r, 2, 2);
    }

    ctx.restore();
  }
};
