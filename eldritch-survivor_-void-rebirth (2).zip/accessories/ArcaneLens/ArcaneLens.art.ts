
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    const strokeWidth = Math.max(1.5, size * 0.06);
    const shineOpacity = 0.7;

    // Corpo da Lente (Efeito de Vidro/Gradiente)
    const grad = ctx.createLinearGradient(-size * 0.4, -size * 0.6, size * 0.4, size * 0.6);
    grad.addColorStop(0, 'rgba(230, 240, 255, 0.8)');
    grad.addColorStop(0.5, 'rgba(100, 100, 255, 0.4)');
    grad.addColorStop(1, 'rgba(50, 50, 150, 0.6)');

    ctx.fillStyle = grad;
    ctx.strokeStyle = '#ccf';
    ctx.lineWidth = strokeWidth;

    ctx.beginPath();
    ctx.ellipse(0, 0, size * 0.4, size * 0.6, Math.PI / 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Brilho Especular
    ctx.globalAlpha = shineOpacity;
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = strokeWidth * 0.8;
    ctx.lineCap = 'round';

    ctx.beginPath();
    ctx.moveTo(-size * 0.25, -size * 0.25);
    ctx.quadraticCurveTo(-size * 0.1, -size * 0.1, 0, 0);
    ctx.stroke();

    ctx.restore();
  },

  drawWorld: (ctx, x, y, size, time) => {
    const hoverOffset = Math.sin(time * 2.5) * 4;
    const breatheScale = 1 + Math.sin(time * 3) * 0.05;

    ctx.save();
    ctx.translate(x, y + hoverOffset);
    ctx.scale(breatheScale, breatheScale);
    art.drawIcon(ctx, 0, 0, size);
    ctx.restore();
  }
};
