
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    // Osso Envelhecido
    const boneColor = '#e3dac9';
    const shadowColor = '#b0a090';
    
    ctx.fillStyle = boneColor;
    ctx.strokeStyle = shadowColor;
    ctx.lineWidth = 1;

    // Crânio
    ctx.beginPath();
    ctx.arc(0, -size * 0.15, size * 0.4, 0, Math.PI * 2); // Caixa craniana
    ctx.fill();
    ctx.stroke();
    
    // Mandíbula
    ctx.beginPath();
    ctx.rect(-size * 0.25, size * 0.15, size * 0.5, size * 0.25);
    ctx.fill();
    ctx.stroke();

    // Dentes
    ctx.fillStyle = shadowColor;
    ctx.beginPath();
    ctx.moveTo(-size * 0.1, size * 0.4); ctx.lineTo(-size * 0.1, size * 0.25);
    ctx.moveTo(size * 0.1, size * 0.4); ctx.lineTo(size * 0.1, size * 0.25);
    ctx.stroke();

    // Olhos (Buracos Negros)
    ctx.fillStyle = '#1a1a1a';
    ctx.beginPath();
    ctx.arc(-size * 0.15, -size * 0.1, size * 0.1, 0, Math.PI * 2);
    ctx.arc(size * 0.15, -size * 0.1, size * 0.1, 0, Math.PI * 2);
    ctx.fill();

    // Chamas nos Olhos (Necrotic)
    ctx.fillStyle = '#00ff00';
    ctx.shadowColor = '#00ff00';
    ctx.shadowBlur = 5;
    ctx.beginPath();
    ctx.arc(-size * 0.15, -size * 0.1, size * 0.04, 0, Math.PI * 2);
    ctx.arc(size * 0.15, -size * 0.1, size * 0.04, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    ctx.restore();
  },
  drawWorld: (ctx, x, y, size, time) => {
    const hover = Math.sin(time * 1.5) * 5;
    const float = Math.sin(time * 3) * 0.1; // Rotação sutil

    ctx.save();
    ctx.translate(x, y + hover);
    ctx.rotate(float);
    art.drawIcon(ctx, 0, 0, size);
    ctx.restore();
  }
};
