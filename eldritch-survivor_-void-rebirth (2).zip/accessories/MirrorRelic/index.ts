
import { definition } from './MirrorRelic.types';
import { logic } from './MirrorRelic.logic';
import { art } from './MirrorRelic.art';

export { definition, logic, art };
