
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    // Gradiente de Vidro/Espelho
    const grad = ctx.createLinearGradient(-size * 0.5, -size * 0.5, size * 0.5, size * 0.5);
    grad.addColorStop(0, '#fff');
    grad.addColorStop(0.5, '#d0e0e3'); // Azul pálido
    grad.addColorStop(1, '#999');

    ctx.fillStyle = grad;
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = size * 0.04;

    // Forma de Fragmento Irregular
    ctx.beginPath();
    ctx.moveTo(0, -size * 0.7);
    ctx.lineTo(size * 0.5, -size * 0.2);
    ctx.lineTo(size * 0.2, size * 0.6);
    ctx.lineTo(-size * 0.5, size * 0.3);
    ctx.lineTo(-size * 0.3, -size * 0.3);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Linha de Reflexo (Diagonal)
    ctx.globalAlpha = 0.6;
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = size * 0.08;
    ctx.beginPath();
    ctx.moveTo(-size * 0.2, -size * 0.2);
    ctx.lineTo(size * 0.2, size * 0.2);
    ctx.stroke();

    ctx.restore();
  },
  drawWorld: (ctx, x, y, size, time) => {
    const hover = Math.sin(time * 2.5) * 4;
    const glint = Math.pow(Math.sin(time * 3), 10); // Brilho repentino

    ctx.save();
    ctx.translate(x, y + hover);
    art.drawIcon(ctx, 0, 0, size);

    // Efeito de "Glint" (Brilho intenso)
    if (glint > 0.1) {
        ctx.globalAlpha = glint;
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(0, -size * 0.2, size * 0.3, 0, Math.PI * 2);
        ctx.fill();
    }

    ctx.restore();
  }
};
