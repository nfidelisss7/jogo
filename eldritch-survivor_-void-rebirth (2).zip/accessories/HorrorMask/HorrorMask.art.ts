
import { AccessoryArt } from '../../types/accessoryTypes';

export const art: AccessoryArt = {
  drawIcon: (ctx, x, y, size) => {
    ctx.save();
    ctx.translate(x, y);

    // Porcelana Pálida
    const grad = ctx.createLinearGradient(-size * 0.4, -size * 0.5, size * 0.4, size * 0.5);
    grad.addColorStop(0, '#fff');
    grad.addColorStop(1, '#ddd');

    ctx.fillStyle = grad;
    ctx.strokeStyle = '#999';
    ctx.lineWidth = 1;

    // Forma da Máscara (Oval alongado)
    ctx.beginPath();
    ctx.ellipse(0, 0, size * 0.35, size * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Olhos (Vazios e Caídos)
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.ellipse(-size * 0.15, -size * 0.1, size * 0.08, size * 0.06, 0.2, 0, Math.PI * 2);
    ctx.ellipse(size * 0.15, -size * 0.1, size * 0.08, size * 0.06, -0.2, 0, Math.PI * 2);
    ctx.fill();

    // Lágrimas Negras (Pintura)
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-size * 0.15, -size * 0.05);
    ctx.lineTo(-size * 0.15, size * 0.2); // Lágrima Esq
    ctx.moveTo(size * 0.15, -size * 0.05);
    ctx.lineTo(size * 0.15, size * 0.2); // Lágrima Dir
    ctx.stroke();

    // Boca (Sorriso Cortado ou Triste)
    ctx.beginPath();
    ctx.arc(0, size * 0.25, size * 0.15, Math.PI + 0.5, -0.5); // Arco invertido (triste)
    ctx.stroke();

    ctx.restore();
  },
  drawWorld: (ctx, x, y, size, time) => {
    const hover = Math.sin(time * 2) * 3;
    // Efeito fantasmagórico (Fade in/out sutil)
    const ghost = 0.8 + Math.sin(time * 5) * 0.2;

    ctx.save();
    ctx.translate(x, y + hover);
    ctx.globalAlpha = ghost;
    art.drawIcon(ctx, 0, 0, size);
    ctx.restore();
  }
};
