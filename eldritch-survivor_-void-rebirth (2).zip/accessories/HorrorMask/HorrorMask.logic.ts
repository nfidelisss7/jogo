
import { AccessoryLogicHandler } from '../../types/accessoryTypes';

export const logic: AccessoryLogicHandler = {
  onUpdate: (player, delta, stats, instance, time, enemies) => {
    const rangeSq = 200 * 200;
    for(const e of enemies) {
        if(!e.active) continue;
        const dx = e.x - player.x;
        const dy = e.y - player.y;
        if(dx*dx + dy*dy < rangeSq) {
            // FIX: Do not modify e.speed permanently (multiplicative decay to 0). 
            // Use slowTimer which the engine handles as a temporary status effect.
            e.slowTimer = 200; // Refreshes the slow duration while in range
        }
    }
  },
  
  onKill: (victim, player, stats, instance) => {
      // Fear chance logic is handled conceptually or requires engine support for fear state
  }
};
