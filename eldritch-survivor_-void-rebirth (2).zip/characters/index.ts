
import { CharacterDefinition, CharacterId } from '../types/CharacterTypes';

export const CharacterRegistry: Record<CharacterId, CharacterDefinition> = {
  [CharacterId.VOID_WALKER]: {
    id: CharacterId.VOID_WALKER,
    name: "Void Walker",
    title: "The Swift Shadow",
    description: "A master of time and space. Attacks faster and moves with unnatural agility, but remains fragile.",
    stats: {
      maxHpMult: 0.8,       // -20% HP
      moveSpeedMult: 1.25,  // +25% Speed
      damageMult: 1.0,
      cooldownMult: 0.85,   // 15% Cooldown Reduction (Faster attacks)
      armor: 0,
      pickupRangeMult: 1.5  // Magnetism
    },
    theme: {
      primaryColor: '#0b0b12',
      secondaryColor: '#2a0535',
      glowColor: '#00ffff', // Cyan
      robeStyle: 'tattered'
    }
  },
  [CharacterId.BLOOD_WEAVER]: {
    id: CharacterId.BLOOD_WEAVER,
    name: "Blood Weaver",
    title: "The Crimson Sage",
    description: "Channels life essence into devastating power. Deals massive damage but moves deliberately.",
    stats: {
      maxHpMult: 1.0,
      moveSpeedMult: 0.9,   // -10% Speed
      damageMult: 1.35,     // +35% Damage
      cooldownMult: 1.0,
      armor: 0,
      pickupRangeMult: 1.0
    },
    theme: {
      primaryColor: '#2a0a0a',
      secondaryColor: '#500',
      glowColor: '#ff0000', // Red
      robeStyle: 'elegant'
    }
  },
  [CharacterId.IRON_WARDEN]: {
    id: CharacterId.IRON_WARDEN,
    name: "Iron Warden",
    title: "The Eternal Sentinel",
    description: "A walking fortress. Possesses immense vitality and armor, standing firm against the horde.",
    stats: {
      maxHpMult: 1.5,       // +50% HP
      moveSpeedMult: 0.85,  // -15% Speed
      damageMult: 0.9,      // -10% Damage
      cooldownMult: 1.0,
      armor: 0.2,           // 20% Damage Reduction naturally
      pickupRangeMult: 0.8
    },
    theme: {
      primaryColor: '#1a1a1a',
      secondaryColor: '#444',
      glowColor: '#ffd700', // Gold
      robeStyle: 'armored'
    }
  }
};
