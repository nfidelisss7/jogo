
import React from 'react';
import { CharacterId } from '../types/CharacterTypes';
import { CharacterRegistry } from '../characters/index';

interface Props {
  onSelect: (id: CharacterId) => void;
}

const CharacterSelectionScreen: React.FC<Props> = ({ onSelect }) => {
  const characters = Object.values(CharacterRegistry);

  return (
    <div className="start-screen-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#050508' }}>
      <h1 className="main-title" style={{ fontSize: '48px', marginBottom: '40px' }}>CHOOSE YOUR VESSEL</h1>
      
      <div className="cards-row" style={{ maxWidth: '1200px', height: 'auto', padding: '20px' }}>
        {characters.map((char) => {
          const { theme, stats } = char;
          
          return (
            <div 
              key={char.id} 
              className="power-card"
              style={{ 
                borderColor: theme.glowColor, 
                height: '500px',
                cursor: 'pointer',
                boxShadow: `0 0 20px ${theme.glowColor}40`
              }}
              onClick={() => onSelect(char.id)}
            >
              <div className="card-header" style={{ borderBottomColor: theme.glowColor }}>
                <div className="card-icon-frame" style={{ borderColor: theme.glowColor, color: theme.glowColor }}>
                  {char.id === CharacterId.VOID_WALKER ? '⚡' : char.id === CharacterId.BLOOD_WEAVER ? '🩸' : '🛡️'}
                </div>
                <div className="card-title-group">
                  <div className="card-name" style={{ color: theme.glowColor }}>{char.name}</div>
                  <div className="card-tag" style={{ borderColor: theme.secondaryColor, color: '#aaa' }}>{char.title}</div>
                </div>
              </div>

              <div className="card-body" style={{ background: `linear-gradient(180deg, ${theme.primaryColor}, #000)` }}>
                <div className="stat-block">
                  <div className="stat-block-title" style={{ color: theme.glowColor }}>Attributes</div>
                  
                  {stats.damageMult !== 1 && (
                    <div className="stat-row">
                      <span>Damage</span>
                      <span className={stats.damageMult > 1 ? 'val-improved' : 'val-decreased'}>
                        {stats.damageMult > 1 ? '+' : ''}{Math.round((stats.damageMult - 1) * 100)}%
                      </span>
                    </div>
                  )}
                  
                  {stats.moveSpeedMult !== 1 && (
                    <div className="stat-row">
                      <span>Speed</span>
                      <span className={stats.moveSpeedMult > 1 ? 'val-improved' : 'val-decreased'}>
                        {stats.moveSpeedMult > 1 ? '+' : ''}{Math.round((stats.moveSpeedMult - 1) * 100)}%
                      </span>
                    </div>
                  )}

                  {stats.maxHpMult !== 1 && (
                    <div className="stat-row">
                      <span>Health</span>
                      <span className={stats.maxHpMult > 1 ? 'val-improved' : 'val-decreased'}>
                        {stats.maxHpMult > 1 ? '+' : ''}{Math.round((stats.maxHpMult - 1) * 100)}%
                      </span>
                    </div>
                  )}

                  {stats.cooldownMult !== 1 && (
                    <div className="stat-row">
                      <span>Cooldowns</span>
                      <span className={stats.cooldownMult < 1 ? 'val-improved' : 'val-decreased'}>
                        {stats.cooldownMult < 1 ? '-' : '+'}{Math.round(Math.abs(1 - stats.cooldownMult) * 100)}%
                      </span>
                    </div>
                  )}

                  {stats.armor > 0 && (
                    <div className="stat-row">
                      <span>Armor</span>
                      <span className="val-improved">+{Math.round(stats.armor * 100)}% DR</span>
                    </div>
                  )}
                </div>

                <div className="description-text" style={{ borderColor: theme.glowColor, marginTop: '20px' }}>
                  {char.description}
                </div>
              </div>

              <div className="card-footer" style={{ borderTopColor: theme.glowColor }}>
                <button className="select-btn" style={{ background: theme.secondaryColor, color: '#fff' }}>
                  EMBARK
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CharacterSelectionScreen;
