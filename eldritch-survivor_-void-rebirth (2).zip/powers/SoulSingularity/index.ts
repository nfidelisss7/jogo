
import { definition } from './SoulSingularity.levels';
import { logic } from './SoulSingularity.logic';
import { art } from './SoulSingularity.art';

export { definition, logic, art };
