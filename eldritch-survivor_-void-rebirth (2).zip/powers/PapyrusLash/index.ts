
import { definition } from './PapyrusLash.levels';
import { logic } from './PapyrusLash.logic';
import { art } from './PapyrusLash.art';

export { definition, logic, art };
