
import { definition } from './AetherGolem.levels';
import { logic } from './AetherGolem.logic';
import { art } from './AetherGolem.art';

export { definition, logic, art };
