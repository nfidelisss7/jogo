
export * from './SoulSingularity/index';
